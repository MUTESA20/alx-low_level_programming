 Memory allocation
