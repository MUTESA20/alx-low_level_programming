 Bit manipulation project
