 more linked list

