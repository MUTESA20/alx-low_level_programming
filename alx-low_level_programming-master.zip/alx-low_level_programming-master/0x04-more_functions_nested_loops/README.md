
0x04. C - More functions, more nested loops
