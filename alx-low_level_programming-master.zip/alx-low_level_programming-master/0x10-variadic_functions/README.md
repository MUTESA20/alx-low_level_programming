0x10. C - Variadic functions
