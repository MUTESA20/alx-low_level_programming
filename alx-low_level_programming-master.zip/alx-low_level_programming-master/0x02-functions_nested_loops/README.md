## function and nested loop

