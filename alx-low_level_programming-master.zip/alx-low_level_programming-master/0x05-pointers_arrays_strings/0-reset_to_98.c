#include "main.h"
/**
 * reset_to_98 - reset argument to 98
 * @n: pointer
 * Return: void
*/

void reset_to_98(int *n)
{

*n = 98;

}
