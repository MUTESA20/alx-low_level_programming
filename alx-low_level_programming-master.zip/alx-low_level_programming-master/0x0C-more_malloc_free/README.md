 Free more memory
