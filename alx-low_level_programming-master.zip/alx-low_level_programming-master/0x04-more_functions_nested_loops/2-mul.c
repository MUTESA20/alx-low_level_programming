#include "main.h"

/**
 * mul - multiply two numbers
 * Description: multiply two numbers
 * @num1: interger value
 * @num2: interger value
 *
 * Return: result
 * Example:
 *      mul(4 * 5) ---> 20
 */

int mul(int num1, int num2)
{
	int result = 0;

	result = num1 * num2;
	return (result);
}
