Linked list project
