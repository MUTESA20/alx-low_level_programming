## C programming Array and Pointer
