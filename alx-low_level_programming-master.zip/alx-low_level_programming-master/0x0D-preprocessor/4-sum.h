#ifndef _sum_h_
#define _sum_h_

#define SUM(x, y) ((x) + (y))

#endif /* _sum_h_ */
