Learning C programming basics
