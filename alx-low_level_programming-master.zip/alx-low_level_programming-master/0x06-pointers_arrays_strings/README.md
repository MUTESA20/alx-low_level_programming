##  pointer arry string
