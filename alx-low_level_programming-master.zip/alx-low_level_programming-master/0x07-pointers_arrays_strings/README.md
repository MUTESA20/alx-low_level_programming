pointer and array string
