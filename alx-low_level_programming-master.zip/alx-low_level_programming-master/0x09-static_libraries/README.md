static library
